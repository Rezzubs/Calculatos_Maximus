self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4517310f3876e72572a7d653f37da250",
    "url": "./index.html"
  },
  {
    "revision": "50984ab13cb09cb9ca3c",
    "url": "./static/css/main.05935c80.chunk.css"
  },
  {
    "revision": "ee3932afd235fbfb63d2",
    "url": "./static/js/2.aef98638.chunk.js"
  },
  {
    "revision": "50984ab13cb09cb9ca3c",
    "url": "./static/js/main.b761448c.chunk.js"
  },
  {
    "revision": "d1402df161b999bacbbe",
    "url": "./static/js/runtime-main.770f65f7.js"
  },
  {
    "revision": "ab0da34e3589b8d5000a093fd7214f1d",
    "url": "./static/media/C.ab0da34e.png"
  },
  {
    "revision": "966cb3c42cc1c98d1cf1d71f9846fbcf",
    "url": "./static/media/CHelp.966cb3c4.png"
  },
  {
    "revision": "f9cce0cfb7feac5048603e5e6d992082",
    "url": "./static/media/Py.f9cce0cf.png"
  },
  {
    "revision": "eded78a8e2d5366831d7a7a581e9aea1",
    "url": "./static/media/V.eded78a8.png"
  },
  {
    "revision": "cc25dc672213044bedab3c190579d825",
    "url": "./static/media/VHelp.cc25dc67.png"
  },
  {
    "revision": "4a64ff75ccd0ee3e73fa8be8f40f41cf",
    "url": "./static/media/VHelp2.4a64ff75.png"
  }
]);